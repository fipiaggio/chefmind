<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Recipe;
use Tymon\JWTAuth\Facades\JWTAuth;
use Validator;
use Storage;
use Input;

class RecipeController extends Controller
{

    public function __construct()
    {
        // Vistas autorizadas
        // Menos Index
        $this->middleware('jwt.auth', ['except' => ['index', 'store', 'destroy', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $recipes = Recipe::all();
        return response()->json($recipes->toArray());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        if($user){
            if(Input::hasFile('file')){
                $file = $request->file('file');
                $path = public_path()."/uploads";
                $fileName = str_random('16') . '.' . $file->getClientOriginalExtension();
                //$file->move($path, $fileName);

                $recipe = new Recipe;
                $recipe->name = $request->name;
                $recipe->description = $request->description;
                $recipe->img = '/upload/'.$fileName;
                $recipe->dificulty = $request->dificulty;
                $recipe->time = $request->time;
                $recipe->cost = $request->cost;
                $recipe->people = $request->people;
                $recipe->user_id = $user->id;

                $contents = Storage::get('3hmWdyoyyf6AxfXO.jpg');
                $testpath = app_path();
                return $testpath;
            }
            return response()->json(['error' =>'Falta cargar imagen'], 401);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $recipe = Recipe::find($id);
        if(!$recipe){
            return response()->json(['error' =>'No existe esa receta'], 401);
        }
        return response()->json($recipe->toArray());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $recipe = Recipe::find($id);
        $recipe->update($request->all());
        return response()->json(['success'], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $recipe = Recipe::find($id);
        $recipe->delete();
        return response()->json(['success'], 200);
    }
}
